izzyftp
_________________________________________

Ligth FTP client for Firefox OS

_________________________________________
Icons are from famfamfam
Silk icon set 1.3

Mark James
http://www.famfamfam.com/lab/icons/silk/
